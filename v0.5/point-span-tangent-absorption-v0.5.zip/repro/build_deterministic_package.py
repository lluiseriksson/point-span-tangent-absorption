#!/usr/bin/env python3
"""Build a deterministic manifest, report, and ZIP for the v0.5 package."""

from __future__ import annotations

import argparse
import hashlib
import json
import zipfile
from pathlib import Path

from pypdf import PdfReader


FIXED_ZIP_TIME = (1980, 1, 1, 0, 0, 0)
EXCLUDED_NAMES = {"MANIFEST.sha256", "BUILD_REPORT.json"}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def payload_files(root: Path, zip_name: str) -> list[Path]:
    return sorted(
        (
            path
            for path in root.rglob("*")
            if path.is_file()
            and path.name not in EXCLUDED_NAMES
            and path.name != zip_name
            and "__pycache__" not in path.parts
        ),
        key=lambda path: path.relative_to(root).as_posix(),
    )


def write_report(root: Path, files: list[Path]) -> Path:
    pdf_path = root / "paper.pdf"
    report = {
        "package": "point-span-tangent-absorption-v0.5",
        "scope": (
            "Metadata covers payload files before BUILD_REPORT.json, "
            "MANIFEST.sha256, and the ZIP itself are created."
        ),
        "paper_pages": len(PdfReader(str(pdf_path)).pages),
        "files": [
            {
                "path": path.relative_to(root).as_posix(),
                "size_bytes": path.stat().st_size,
                "sha256": sha256(path),
            }
            for path in files
        ],
    }
    destination = root / "BUILD_REPORT.json"
    destination.write_text(
        json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    return destination


def write_manifest(root: Path, zip_name: str) -> Path:
    files = sorted(
        (
            path
            for path in root.rglob("*")
            if path.is_file()
            and path.name != "MANIFEST.sha256"
            and path.name != zip_name
            and "__pycache__" not in path.parts
        ),
        key=lambda path: path.relative_to(root).as_posix(),
    )
    destination = root / "MANIFEST.sha256"
    lines = [
        f"{sha256(path)}  {path.relative_to(root).as_posix()}" for path in files
    ]
    destination.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return destination


def write_zip(root: Path, zip_name: str) -> Path:
    destination = root / zip_name
    files = sorted(
        (
            path
            for path in root.rglob("*")
            if path.is_file()
            and path.name != zip_name
            and "__pycache__" not in path.parts
        ),
        key=lambda path: path.relative_to(root).as_posix(),
    )
    with zipfile.ZipFile(
        destination,
        mode="w",
        compression=zipfile.ZIP_DEFLATED,
        compresslevel=9,
    ) as archive:
        for path in files:
            relative = path.relative_to(root).as_posix()
            info = zipfile.ZipInfo(relative, date_time=FIXED_ZIP_TIME)
            info.create_system = 3
            info.external_attr = 0o100644 << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, path.read_bytes(), compresslevel=9)
    return destination


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--zip-name",
        default="point-span-tangent-absorption-v0.5.zip",
    )
    args = parser.parse_args()

    root = Path(__file__).resolve().parent.parent
    initial_files = payload_files(root, args.zip_name)
    write_report(root, initial_files)
    write_manifest(root, args.zip_name)
    archive = write_zip(root, args.zip_name)
    result = {
        "status": "PASS",
        "zip": archive.name,
        "zip_size_bytes": archive.stat().st_size,
        "zip_sha256": sha256(archive),
        "manifest_entries": len(
            (root / "MANIFEST.sha256").read_text(encoding="utf-8").splitlines()
        ),
    }
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

