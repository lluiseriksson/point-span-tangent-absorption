# Exact finite replays for manuscript v0.5

The scripts in this directory use only the Python standard library. They are
deterministic and perform exact arithmetic.

Run the complete suite from this directory:

```powershell
python run_all_replays.py
```

This writes individual reports under `results/` and a package-level
`../results.json` summary.

## Scripts

- `verify_simplex_fixtures.py` uses `fractions.Fraction` to verify the exact
  value and value-plus-first-jet ranks of three fixtures:
  - three points on a linearly embedded `P^1` for `m=2`;
  - the ten points `[1:i:j]`, `i,j >= 0`, `i+j <= 3`, for `P^2,m=3`;
  - the twenty points `[1:i:j:k]`, `i,j,k >= 0`, `i+j+k <= 3`, for
    `P^3,m=3`.
- `verify_linear_p1_sharpness.py` retains the exact rational four-point
  `P^1,m=3` fixture from the previous package.
- `verify_quadric_tangent_absorption.py` retains the integer/modular quadric
  grid: 23 first-jet fixtures and five degree-two full-span obstructions.
- `run_all_replays.py` executes every replay and records source and result
  hashes.

For the ten-point plane fixture, the expected result is

```text
value rank over Q                    = 10
value plus all first-jet rank over Q = 10
```

The unchanged augmented rank means only that this displayed point set already
fills `H^0(P^2,O(3))^*`; it does not prove the universal lower bound.

## Scope boundary

These computations certify finite matrices and explicit fixtures. They do not
prove the main theorem, the characteristic-zero Gauss-branch lemma, novelty,
publication priority, or any classification of equality cases. Those claims
must stand on the written proofs and external mathematical review.
