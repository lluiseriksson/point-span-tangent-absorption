#!/usr/bin/env python3
"""Exact rational replays for the simplex-lattice fixtures in manuscript v0.5.

The script verifies only the displayed finite configurations.  It does not
prove the universal theorem, the Gauss-branch lemma, or a classification of
equality cases.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from fractions import Fraction
from itertools import product
from math import comb
from typing import Iterable, Sequence


def monomial_basis(variable_count: int, degree: int) -> list[tuple[int, ...]]:
    """Exponent vectors of all affine monomials of total degree at most degree."""

    return [
        exponent
        for exponent in product(range(degree + 1), repeat=variable_count)
        if sum(exponent) <= degree
    ]


def simplex_points(variable_count: int, degree: int) -> list[tuple[int, ...]]:
    """Integral simplex lattice: nonnegative tuples with coordinate sum <= degree."""

    return [
        point
        for point in product(range(degree + 1), repeat=variable_count)
        if sum(point) <= degree
    ]


def monomial_value(exponent: Sequence[int], point: Sequence[int]) -> int:
    value = 1
    for power, coordinate in zip(exponent, point):
        value *= coordinate**power
    return value


def monomial_derivative(
    exponent: Sequence[int], point: Sequence[int], coordinate_index: int
) -> int:
    power = exponent[coordinate_index]
    if power == 0:
        return 0
    value = power
    for index, (other_power, coordinate) in enumerate(zip(exponent, point)):
        value *= coordinate ** (other_power - (1 if index == coordinate_index else 0))
    return value


def value_row(
    basis: Sequence[Sequence[int]], point: Sequence[int]
) -> list[int]:
    return [monomial_value(exponent, point) for exponent in basis]


def jet_rows(
    basis: Sequence[Sequence[int]], point: Sequence[int]
) -> list[list[int]]:
    return [
        value_row(basis, point),
        *[
            [
                monomial_derivative(exponent, point, coordinate_index)
                for exponent in basis
            ]
            for coordinate_index in range(len(point))
        ],
    ]


def rational_rank(matrix: Iterable[Sequence[int]]) -> int:
    """Exact Gaussian-elimination rank over Q using Fraction."""

    work = [[Fraction(entry) for entry in row] for row in matrix]
    if not work:
        return 0
    column_count = len(work[0])
    if any(len(row) != column_count for row in work):
        raise ValueError("ragged matrix")

    row_count = len(work)
    pivot_row = 0
    for column in range(column_count):
        pivot = next(
            (row for row in range(pivot_row, row_count) if work[row][column]),
            None,
        )
        if pivot is None:
            continue
        work[pivot_row], work[pivot] = work[pivot], work[pivot_row]
        pivot_value = work[pivot_row][column]
        work[pivot_row] = [entry / pivot_value for entry in work[pivot_row]]
        for row in range(row_count):
            if row == pivot_row:
                continue
            coefficient = work[row][column]
            if coefficient:
                work[row] = [
                    entry - coefficient * pivot_entry
                    for entry, pivot_entry in zip(work[row], work[pivot_row])
                ]
        pivot_row += 1
        if pivot_row == row_count:
            break
    return pivot_row


def matrix_sha256(matrix: Sequence[Sequence[int]]) -> str:
    payload = json.dumps(matrix, separators=(",", ":")).encode("ascii")
    return hashlib.sha256(payload).hexdigest()


def verify_fixture(variable_count: int, degree: int) -> dict[str, object]:
    basis = monomial_basis(variable_count, degree)
    points = simplex_points(variable_count, degree)
    values = [value_row(basis, point) for point in points]
    augmented = [row for point in points for row in jet_rows(basis, point)]
    value_rank = rational_rank(values)
    augmented_rank = rational_rank(augmented)
    expected = comb(variable_count + degree, variable_count)
    passed = (
        len(basis) == expected
        and len(points) == expected
        and value_rank == expected
        and augmented_rank == expected
    )
    return {
        "variety": f"linearly embedded P^{variable_count}",
        "m": degree,
        "affine_points": [list(point) for point in points],
        "basis_size": len(basis),
        "point_count": len(points),
        "expected_dimension": expected,
        "value_rank_over_Q": value_rank,
        "value_plus_all_first_jets_rank_over_Q": augmented_rank,
        "value_matrix_sha256": matrix_sha256(values),
        "status": "PASS" if passed else "FAIL",
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    fixtures = [
        verify_fixture(variable_count=1, degree=2),
        verify_fixture(variable_count=2, degree=3),
        verify_fixture(variable_count=3, degree=3),
    ]
    passed = all(fixture["status"] == "PASS" for fixture in fixtures)
    report = {
        "status": "PASS" if passed else "FAIL",
        "arithmetic": "exact Gaussian elimination over Q using Fraction",
        "scope": (
            "Finite fixture certification only: P1,m=2; P2,m=3; P3,m=3. "
            "This is not a proof of the universal theorem or the Gauss lemma."
        ),
        "fixtures": fixtures,
    }

    if args.json:
        print(json.dumps(report, indent=2, sort_keys=True))
    else:
        print("EXACT SIMPLEX-LATTICE FIXTURES")
        for fixture in fixtures:
            print(
                f"{fixture['variety']}, m={fixture['m']}: "
                f"points={fixture['point_count']}, "
                f"value rank={fixture['value_rank_over_Q']}, "
                f"value+jets rank={fixture['value_plus_all_first_jets_rank_over_Q']} "
                f"[{fixture['status']}]"
            )
        print(f"OVERALL: {report['status']}")
        print(f"SCOPE: {report['scope']}")
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())

