# Point-span tangent absorption, version 0.5

This directory is the self-contained research-paper package for
**Rank Bounds and a Gauss-Fiber Alternative for Point-Span Tangent
Absorption**.

## Contents

- `manuscript.tex`: authoritative LaTeX source.
- `paper.pdf`: compiled ten-page paper.
- `paper.txt`: text extracted from the compiled PDF.
- `REVIEW_RESPONSE.md`: response to the mathematical and editorial audit.
- `results.json`: summary of the exact finite replays.
- `repro/`: standard-library replay programs, detailed JSON results, package
  builder, and package verifier.
- `BUILD_REPORT.json`: sizes and SHA-256 hashes for payload files.
- `MANIFEST.sha256`: standard SHA-256 manifest.
- `point-span-tangent-absorption-v0.5.zip`: deterministic archive.

## Reproduce the finite checks

From the package root:

```powershell
python repro/run_all_replays.py
```

The suite uses exact rational arithmetic for the line and simplex-lattice
fixtures, and exact modular certificates for the integral quadric fixtures.
It requires no third-party Python package.

## Compile the paper

With a LaTeX installation containing the packages named in the preamble:

```powershell
pdflatex -interaction=nonstopmode -halt-on-error manuscript.tex
pdflatex -interaction=nonstopmode -halt-on-error manuscript.tex
```

The committed output was built with MiKTeX pdfTeX 1.40.28. A different TeX
distribution may produce a bytewise different PDF while preserving content.

## Verify the package

The packaging helpers require `pypdf`:

```powershell
python -m pip install pypdf
python repro/build_deterministic_package.py
python repro/verify_package.py
```

Running the builder twice without changing the payload must yield the same ZIP
SHA-256. The verifier checks every manifest entry, every ZIP member, fixed ZIP
timestamps, path safety, and equality between archived and current bytes.

## Scope

Passing replays certify only the displayed finite fixtures. They are not a
proof of the universal theorem, novelty, or priority. The paper is stated over
the complex numbers; it does not assert the Gauss-branch result in positive
characteristic. No submission, release, PR, or external publication is implied
by this local package.
