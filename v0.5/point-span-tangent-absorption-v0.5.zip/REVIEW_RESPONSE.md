# Review response for version 0.5

## Scope of this revision

Version 0.5 was prepared as a copy. The source manuscript at
`C:\Users\lluis\Documents\Codex\2026-08-14\hemos-creado-nuestro-propio-archivo-para\work\quadric_tangent_absorption\manuscript.tex`
was not edited. Its SHA-256 remained
`4E280AC781337B86A76C71C73CC0CA844D896DA5D5D94203A2138D44C2EA5568`.

This response records what was changed and what the available evidence does
and does not establish. It is not an external peer-review report and makes no
claim of publication priority.

## Mathematical changes

1. **Main bound.** The principal statement is now

   ```text
   dim S_Z, |Z| >= min{(d+1)(d+2), binom(d+m,d)}.
   ```

   The earlier square floor `(d+1)^2` is retained and proved first, but is no
   longer presented as the final bound.

   A separately attributed jet-ampleness consequence now strengthens this to

   ```text
   dim S_Z, |Z| >= max{J(d,m), min{(d+1)(d+2), binom(d+m,d)}},
   J(d,m) = floor((m+1)/2)(d+1) + 1 if m is even.
   ```

   This is stated only as a lower bound. It follows from
   Beltrametti--Di Rocco--Sommese, Proposition 2.3: `H` is 1-jet ample and
   `H^m` is therefore `m`-jet ample. It improves the constant branch for every
   `m >= 2d+4`.

2. **Independent-support branch.** The first-jet independence input is
   explicitly attributed to Ballico--Chiantini, *Milan Journal of
   Mathematics* 89 (2021), Theorem 3.5,
   DOI `10.1007/s00032-020-00324-5`. The manuscript spells out the
   specialization

   ```text
   H = O_X(1),  L1 = H^2,  L2 = H^(m-2),  L1 tensor L2 = H^m.
   ```

   For projectively independent supports, the sections `h_q^(m-2)` separate
   their values for `L2`. For each support `p`, the quadrics `h_q^2` and
   `h_p a` verify condition dagger for `(X,H^2,S)`. The squared-hyperplane
   induction is retained as a direct proof of this specialization, not
   presented as a new general jet theorem.

3. **Gauss branch.** A new characteristic-zero lemma is included. With
   `R = Sym(W*)` and `I = I(Z)`, absorption and the equality
   `T_hat_p X = W` imply

   ```text
   I_m is contained in the intersection of I(p)^2 over p in Z.
   ```

   If `I_m` were nonzero, a nonzero element `F` of minimal degree
   `alpha <= m` could be multiplied, separately at each support, by a form
   `G_p` of degree `m-alpha` that is a local unit at `p`. This forces `F` to
   vanish to second order at every support. Every first partial derivative of
   `F` then lies in `I(Z)` and has smaller degree. In characteristic zero at
   least one derivative is nonzero, contradicting minimality. Hence `I_m=0`,
   and the degree-`m` evaluation map on `P(W)` is injective.

4. **Consequences.** The manuscript now derives:

   - the strong bound `(d+1)(d+2)` for every `d >= 3`, `m >= 3`;
   - the strong bound `12` for `d=2`, `m >= 4`;
   - the exact uniform value `10` for `d=2`, `m=3`;
   - impossibility of equality `dim S_Z=(d+1)^2` for every `d >= 2`;
   - the improved Gauss threshold `g_X(Z) < binom(d+m,d)`.

5. **Exact examples and degree threshold.** The ten points
   `[1:i:j]`, `i,j >= 0`, `i+j <= 3`, are proved cubically unisolvent by the
   successive layers `y=0,1,2,3`. A proved simplex-lattice lemma gives
   unisolvence for every lattice `Delta_(n,r)` and certifies the analogous
   twenty-point fixture in `P^3`. Three points on a
   linearly embedded `P^1` for `m=2` fill `H^0(P^1,O(2))*`, giving dimension
   `3 < 4` and showing that the uniform hypothesis `m >= 3` is necessary.

6. **Scope and attribution.** The discussion now distinguishes point-span
   absorption from Terracini loci, jet ampleness, and strong base loci. It
   cites Beltrametti--Di Rocco--Sommese (1999),
   DOI `10.5209/rev_REMA.1999.v12.n1.17182`, and removes claims based on a
   bounded search as evidence of novelty. Positive characteristic is excluded
   from the theorem because the displayed derivative argument does not handle
   `p`th powers. It also records the exact implication to strong base loci:
   absorption identifies `S_Z` with the span of the tangent spaces, so points
   outside a minimal tangent-generating subset lie in its strong base locus.

7. **Post-referee clarifications.** The complete `H^m`-embedding is denoted
   by `varphi_m`, not by an ambient Veronese symbol, because `X` need not be
   projectively normal. The Gauss proof now explicitly records the surjection
   `Sym^m(V*) -> Sym^m(W*)` and proves in local coordinates that a zero full
   first jet is equivalent to membership in `I(p)^2`.

## Adversarial audit

### Gauss-branch lemma

- **Quantifier check:** `G_p` is allowed to depend on `p`; the argument needs
  only one local unit for each support and does not assert a simultaneous
  separator.
- **Degree check:** minimality gives `1 <= alpha <= m`. When `alpha=m`, a
  nonzero constant is a valid `G_p`.
- **Local-to-point check:** from `G_p F in I(p)^2` and `G_p(p) != 0`, the germ
  of `G_p` is invertible, so the germ of `F` lies in the square of the maximal
  ideal. This is exactly what is needed to make every first derivative vanish
  at `p`; no unsupported global ideal quotient is used.
- **Radicality check:** because `Z` is reduced, a homogeneous form vanishing
  at every support belongs to `I(Z)`.
- **Characteristic check:** the contradiction that some partial derivative is
  nonzero uses characteristic zero. The theorem is therefore not extended to
  positive characteristic.
- **Rank check:** `I_m=0` makes `R_m -> C^Z` injective. Its rank is
  `dim R_m=binom(d+m,d)` and is bounded above by both the full value rank and
  the number of columns `|Z|`.

No logical gap was found in these steps. This is an internal adversarial audit,
not independent external validation.

### Jet-ampleness supplement

- **Source check:** the primary 1999 paper defines `k`-jet ampleness using
  positive weights summing to `k+1`, identifies very ampleness with
  1-jet ampleness for line bundles, and proves tensor-product additivity in
  Proposition 2.3.
- **Odd degree:** for `m=2q+1`, fewer than `q+1` supports would make all of
  `2Z` independent after thickening one support to total weight `m+1`, which
  contradicts absorption. On `q+1` supports, the double-point blocks have
  independent total dimension `(q+1)(d+1)`.
- **Even degree:** for `m=2q`, the same contradiction gives at least `q+1`
  supports. Taking `q` doubles and one additional simple point yields
  independent dimension `q(d+1)+1` inside `S_Z`.
- **Exactness check:** the result is not claimed to be exact in general and is
  combined with, rather than substituted for, the Gauss-fiber bound.

### Independent skeptical review

An independent read-only referee assigned the pre-amendment v0.5 package
`6.2/10.0` with an uncertainty interval of `5.5--6.9`. The component scores
were correctness `8.7`, novelty `4.4`, depth `5.5`, applications `4.2`,
reproducibility `9.2`, and external validation `2.0`. No P0 error was found.
The referee's P1 requests concerning the complete embedding, extension of
forms, double-point identification, and the `P^3` proof were implemented and
then reaudited as correct. The score has not been silently recomputed after
those amendments.

### Numerical thresholds

For `m>=3`,

```text
binom(d+m,d) >= binom(d+3,d)
              = (d+1)(d+2)(d+3)/6.
```

For `d>=3`, the last expression is at least `(d+1)(d+2)`. For `d=2,m>=4`,
`binom(m+2,2) >= 15 > 12`. At `d=2,m=3`, the two branch bounds are `12` and
`10`. Finally,

```text
binom(d+3,d) > (d+1)^2
```

is equivalent to `d(d-1)>0`, so both branch bounds strictly exceed the square
floor when `d>=2`.

### Exact replay evidence

The standard-library replay suite reports `PASS` throughout:

| Fixture | Points | Value rank | Value plus all first jets |
|---|---:|---:|---:|
| linearly embedded `P^1`, `m=2` | 3 | 3 | 3 |
| linearly embedded `P^2`, `m=3` | 10 | 10 | 10 |
| linearly embedded `P^3`, `m=3` | 20 | 20 | 20 |

The quadric replay also reports `PASS` for 23 selected first-jet fixtures and
five degree-two full-span obstructions. These computations certify only the
displayed finite matrices; they do not prove the universal theorem.

## Mechanical and build verification

- The specified accidental repetition of the finiteness/reducedness qualifiers:
  absent.
- `First jets and absorption` section headers: exactly one.
- Duplicate LaTeX labels: zero.
- Missing internal references: zero.
- Missing bibliography entries for cited keys: zero.
- LaTeX passes: two successful final passes with MiKTeX pdfLaTeX.
- Final log: zero LaTeX errors, undefined references, undefined citations,
  overfull boxes, underfull boxes, or warnings.
- Final PDF: 10 A4 pages.
- Visual inspection: all 10 pages were freshly rendered at 150 DPI and
  inspected; no clipped text,
  overlap, broken glyph, or margin defect observed.
- Extracted PDF text contains the Gauss lemma, the exact plane example, the
  jet-ampleness supplement, and the Ballico--Chiantini DOI, with no Unicode
  replacement characters.

## Remaining external validation

The proof has been checked internally, subjected to an independent skeptical
read-only review, and its exact fixtures replayed. It has not received journal
peer review or formal-proof verification. The literature comparison remains
nonexhaustive. Publication, ARR submission, repository pushes, releases, and
public metadata creation were not performed in this revision.
