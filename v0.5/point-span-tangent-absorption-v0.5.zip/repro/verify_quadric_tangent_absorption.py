#!/usr/bin/env python3
"""Exact finite replay for tangent absorption on Veronese-reembedded quadrics.

This program checks finite-dimensional algebra used by the proposed theorem.
It is not a proof of the universal theorem and it does not test any Hodge claim.

The affine chart is

    q = x_0*x_{d+1} + x_1^2 + ... + x_d^2 = 0,
    x_0 = 1,
    x_i = y_i,
    x_{d+1} = -(y_1^2 + ... + y_d^2).

With a monomial order whose leading term of q is x_0*x_{d+1}, a degree-m
quotient basis consists of monomials not divisible by x_0*x_{d+1}.  Values
and first derivatives are computed over the integers and their ranks are then
computed exactly over two prime fields.  A nonzero minor modulo a prime is, in
particular, a nonzero integer minor and therefore also certifies the same rank
over Q and C for the displayed integral points.
"""

from __future__ import annotations

import argparse
import hashlib
import itertools
import json
from dataclasses import asdict, dataclass
from math import comb
from typing import Iterable, Iterator, Sequence


PRIMES = (1_000_003, 1_000_033)
MODEL = "q=x0*x_(d+1)+sum_(i=1)^d xi^2; x0=1; x_(d+1)=-sum yi^2"


def weak_compositions(total: int, length: int) -> Iterator[tuple[int, ...]]:
    """Yield all length-``length`` nonnegative tuples summing to ``total``."""

    if length == 1:
        yield (total,)
        return
    for first in range(total + 1):
        for tail in weak_compositions(total - first, length - 1):
            yield (first,) + tail


def quotient_basis(d: int, m: int) -> list[tuple[int, ...]]:
    """Return standard degree-m monomials modulo the single quadric relation."""

    variable_count = d + 2
    return [
        exponent
        for exponent in weak_compositions(m, variable_count)
        if not (exponent[0] > 0 and exponent[-1] > 0)
    ]


def h0_quadric(d: int, m: int) -> int:
    """Dimension of H^0(Q^d,O_Q(m)) from the hypersurface exact sequence."""

    ambient = comb(d + m + 1, m)
    relation = comb(d + m - 1, m - 2) if m >= 2 else 0
    return ambient - relation


def product(values: Iterable[int]) -> int:
    out = 1
    for value in values:
        out *= value
    return out


def value_and_gradient(
    exponent: Sequence[int], point: Sequence[int]
) -> tuple[int, tuple[int, ...]]:
    """Evaluate one quotient monomial and its affine gradient over Z."""

    middle = exponent[1:-1]
    last_power = exponent[-1]
    ell = -sum(coordinate * coordinate for coordinate in point)
    point_factor = product(
        coordinate**power for coordinate, power in zip(point, middle)
    )
    value = point_factor * ell**last_power

    gradient: list[int] = []
    for index, coordinate in enumerate(point):
        power = middle[index]
        direct = 0
        if power > 0:
            direct_factor = power * coordinate ** (power - 1)
            direct_factor *= product(
                other_coordinate**other_power
                for other_index, (other_coordinate, other_power) in enumerate(
                    zip(point, middle)
                )
                if other_index != index
            )
            direct = direct_factor * ell**last_power

        chain = 0
        if last_power > 0:
            chain = (
                point_factor
                * last_power
                * ell ** (last_power - 1)
                * (-2 * coordinate)
            )
        gradient.append(direct + chain)

    return value, tuple(gradient)


def point_value_row(
    basis: Sequence[Sequence[int]], point: Sequence[int]
) -> list[int]:
    return [value_and_gradient(exponent, point)[0] for exponent in basis]


def double_point_rows(
    basis: Sequence[Sequence[int]], point: Sequence[int]
) -> list[list[int]]:
    evaluations = [value_and_gradient(exponent, point) for exponent in basis]
    rows = [[value for value, _ in evaluations]]
    for coordinate_index in range(len(point)):
        rows.append(
            [gradient[coordinate_index] for _, gradient in evaluations]
        )
    return rows


def rank_mod_prime(matrix: Sequence[Sequence[int]], prime: int) -> int:
    """Exact row rank by Gaussian elimination over F_prime."""

    if not matrix:
        return 0
    column_count = len(matrix[0])
    if any(len(row) != column_count for row in matrix):
        raise ValueError("ragged matrix")

    work = [[entry % prime for entry in row] for row in matrix]
    row_count = len(work)
    rank = 0
    for column in range(column_count):
        pivot = next(
            (row for row in range(rank, row_count) if work[row][column]), None
        )
        if pivot is None:
            continue
        work[rank], work[pivot] = work[pivot], work[rank]
        inverse = pow(work[rank][column], prime - 2, prime)
        work[rank] = [(entry * inverse) % prime for entry in work[rank]]

        for row in range(rank + 1, row_count):
            coefficient = work[row][column]
            if coefficient:
                work[row] = [
                    (entry - coefficient * pivot_entry) % prime
                    for entry, pivot_entry in zip(work[row], work[rank])
                ]
        rank += 1
        if rank == row_count:
            break
    return rank


def matrix_digest(matrix: Sequence[Sequence[int]]) -> str:
    payload = json.dumps(matrix, separators=(",", ":")).encode("ascii")
    return hashlib.sha256(payload).hexdigest()


def independent_double_test_points(d: int) -> list[tuple[int, ...]]:
    """Integral d+2 point fixture: zero, coordinate points, and one dense point."""

    zero = (0,) * d
    coordinate_points = [
        tuple(int(index == coordinate) for index in range(d))
        for coordinate in range(d)
    ]
    dense = tuple(coordinate + 2 for coordinate in range(d))
    points = [zero, *coordinate_points, dense]
    if len(set(points)) != d + 2:
        raise AssertionError("the integral fixture must contain d+2 distinct points")
    return points


def lcg_points(d: int, seed: int) -> Iterator[tuple[int, ...]]:
    """Deterministic small integral points; no probabilistic claim is made."""

    state = seed & 0xFFFFFFFF
    seen: set[tuple[int, ...]] = set()
    while True:
        coordinates: list[int] = []
        for _ in range(d):
            state = (1_664_525 * state + 1_013_904_223) & 0xFFFFFFFF
            coordinates.append(int(state % 1009) - 504)
        point = tuple(coordinates)
        if point not in seen:
            seen.add(point)
            yield point


def greedy_full_span_points(
    d: int, m: int, basis: Sequence[Sequence[int]], prime: int
) -> tuple[list[tuple[int, ...]], list[list[int]]]:
    """Find an explicit integral point set spanning the entire value space."""

    target = len(basis)
    selected_points: list[tuple[int, ...]] = []
    selected_rows: list[list[int]] = []
    rank = 0
    candidates = lcg_points(d, seed=0x20260815 + 97 * d + m)
    for _ in range(50_000):
        point = next(candidates)
        row = point_value_row(basis, point)
        candidate_rank = rank_mod_prime([*selected_rows, row], prime)
        if candidate_rank > rank:
            selected_points.append(point)
            selected_rows.append(row)
            rank = candidate_rank
            if rank == target:
                return selected_points, selected_rows
    raise AssertionError(f"failed to find a full-span fixture for d={d}, m={m}")


@dataclass(frozen=True)
class JetRankResult:
    d: int
    m: int
    h0: int
    point_count: int
    expected_rank: int
    ranks: tuple[int, int]
    sha256: str
    status: str


@dataclass(frozen=True)
class FullSpanResult:
    d: int
    m: int
    h0: int
    proposed_floor: int
    selected_points: int
    value_ranks: tuple[int, int]
    value_plus_tangent_ranks: tuple[int, int]
    sha256: str
    status: str


def run_jet_rank_grid() -> list[JetRankResult]:
    results: list[JetRankResult] = []
    grid = list(itertools.product(range(1, 6), range(3, 6)))
    grid.extend((d, 3) for d in range(6, 14))
    for d, m in grid:
        basis = quotient_basis(d, m)
        expected_h0 = h0_quadric(d, m)
        if len(basis) != expected_h0:
            raise AssertionError(
                f"quotient basis mismatch for d={d}, m={m}: "
                f"{len(basis)} != {expected_h0}"
            )

        points = independent_double_test_points(d)
        matrix = [
            row
            for point in points
            for row in double_point_rows(basis, point)
        ]
        expected_rank = (d + 1) * (d + 2)
        ranks = tuple(rank_mod_prime(matrix, prime) for prime in PRIMES)
        status = "PASS" if all(rank == expected_rank for rank in ranks) else "FAIL"
        results.append(
            JetRankResult(
                d=d,
                m=m,
                h0=expected_h0,
                point_count=len(points),
                expected_rank=expected_rank,
                ranks=(ranks[0], ranks[1]),
                sha256=matrix_digest(matrix),
                status=status,
            )
        )
    return results


def run_degree_two_full_span_checks() -> list[FullSpanResult]:
    results: list[FullSpanResult] = []
    for d in range(1, 6):
        m = 2
        basis = quotient_basis(d, m)
        h0 = h0_quadric(d, m)
        if len(basis) != h0:
            raise AssertionError(f"degree-two quotient basis mismatch for d={d}")

        floor = (d + 1) * (d + 2)
        if not h0 < floor:
            raise AssertionError(f"degree-two dimension is not below floor for d={d}")

        points, value_matrix = greedy_full_span_points(d, m, basis, PRIMES[0])
        if len(points) != h0:
            raise AssertionError("a basis-sized full-span fixture was expected")

        value_ranks = tuple(
            rank_mod_prime(value_matrix, prime) for prime in PRIMES
        )
        all_tangent_rows = [
            row
            for point in points
            for row in double_point_rows(basis, point)[1:]
        ]
        augmented = [*value_matrix, *all_tangent_rows]
        augmented_ranks = tuple(
            rank_mod_prime(augmented, prime) for prime in PRIMES
        )
        status = (
            "PASS"
            if all(rank == h0 for rank in value_ranks)
            and all(rank == h0 for rank in augmented_ranks)
            else "FAIL"
        )
        results.append(
            FullSpanResult(
                d=d,
                m=m,
                h0=h0,
                proposed_floor=floor,
                selected_points=len(points),
                value_ranks=(value_ranks[0], value_ranks[1]),
                value_plus_tangent_ranks=(
                    augmented_ranks[0],
                    augmented_ranks[1],
                ),
                sha256=matrix_digest(value_matrix),
                status=status,
            )
        )
    return results


def print_human_report(
    jet_results: Sequence[JetRankResult],
    full_span_results: Sequence[FullSpanResult],
) -> None:
    print("FINITE EXACT REPLAY — QUADRIC TANGENT ABSORPTION")
    print(f"model: {MODEL}")
    print(f"exact rank fields: F_{PRIMES[0]} and F_{PRIMES[1]}")
    print()
    print("Jet-rank fixture: d+2 integral points, values plus first derivatives")
    print(" d  m    h0  points  expected  rank(p1)  rank(p2)  status")
    for result in jet_results:
        print(
            f"{result.d:2d} {result.m:2d} {result.h0:5d} "
            f"{result.point_count:7d} {result.expected_rank:9d} "
            f"{result.ranks[0]:9d} {result.ranks[1]:9d}  {result.status}"
        )

    print()
    print("Degree-two full-span obstruction")
    print(" d  m    h0  claimed-floor  points  value-ranks  +tangent-ranks  status")
    for result in full_span_results:
        print(
            f"{result.d:2d} {result.m:2d} {result.h0:5d} "
            f"{result.proposed_floor:14d} {result.selected_points:7d} "
            f"{str(result.value_ranks):>13s} "
            f"{str(result.value_plus_tangent_ranks):>15s}  {result.status}"
        )

    print()
    print(
        "Interpretation: the m=2 point rows span the complete ambient value "
        "space; adding every displayed tangent row does not increase rank. "
        "Thus tangent absorption is automatic while #points=h0 is strictly "
        "below (d+1)(d+2)."
    )
    print()
    print(
        "SCOPE WARNING: these are exact finite rank checks and explicit "
        "counterexample fixtures. They test normalizations and selected cases "
        "through d=13; they do not prove the universal Gauss-fibre m>=3 "
        "theorem, its novelty, the Hodge Conjecture, or any Millennium problem."
    )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--json",
        action="store_true",
        help="emit the replay result as JSON instead of the human-readable tables",
    )
    args = parser.parse_args()

    jet_results = run_jet_rank_grid()
    full_span_results = run_degree_two_full_span_checks()
    passed = all(result.status == "PASS" for result in jet_results) and all(
        result.status == "PASS" for result in full_span_results
    )

    if args.json:
        print(
            json.dumps(
                {
                    "status": "PASS" if passed else "FAIL",
                    "scope": (
                        "Exact finite replay over two prime fields; not a proof "
                        "of the universal theorem or any Hodge claim."
                    ),
                    "model": MODEL,
                    "primes": PRIMES,
                    "jet_rank_grid": [asdict(result) for result in jet_results],
                    "degree_two_full_span": [
                        asdict(result) for result in full_span_results
                    ],
                },
                indent=2,
                sort_keys=True,
            )
        )
    else:
        print_human_report(jet_results, full_span_results)
        print(f"OVERALL: {'PASS' if passed else 'FAIL'}")
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
