#!/usr/bin/env python3
"""Exact replay of the sharpness example X=P^1, m=3, |Z|=4."""

from __future__ import annotations

import argparse
import json
from fractions import Fraction


def rank(matrix: list[list[int]]) -> int:
    work = [[Fraction(value) for value in row] for row in matrix]
    if not work:
        return 0
    rows, cols = len(work), len(work[0])
    pivot_row = 0
    for col in range(cols):
        pivot = next(
            (row for row in range(pivot_row, rows) if work[row][col]), None
        )
        if pivot is None:
            continue
        work[pivot_row], work[pivot] = work[pivot], work[pivot_row]
        scale = work[pivot_row][col]
        work[pivot_row] = [entry / scale for entry in work[pivot_row]]
        for row in range(rows):
            if row == pivot_row or not work[row][col]:
                continue
            factor = work[row][col]
            work[row] = [
                entry - factor * pivot_entry
                for entry, pivot_entry in zip(work[row], work[pivot_row])
            ]
        pivot_row += 1
        if pivot_row == rows:
            break
    return pivot_row


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    parameters = [0, 1, 2, 3]
    values = [[1, t, t * t, t * t * t] for t in parameters]
    derivatives = [[0, 1, 2 * t, 3 * t * t] for t in parameters]
    value_rank = rank(values)
    value_plus_tangent_rank = rank([*values, *derivatives])

    d = 1
    baseline = (d + 1) ** 2
    strong_floor = (d + 1) * (d + 2)
    gauss_multiplicity = len(parameters)  # Gauss map P^1 -> Gr(2,2) is constant.
    passed = (
        value_rank == 4
        and value_plus_tangent_rank == 4
        and len(parameters) == baseline
        and gauss_multiplicity == baseline
        and value_rank < strong_floor
    )
    report = {
        "variety": "linearly embedded P^1",
        "m": 3,
        "affine_parameters": parameters,
        "value_rank": value_rank,
        "value_plus_tangent_rank": value_plus_tangent_rank,
        "point_count": len(parameters),
        "baseline_floor": baseline,
        "strong_floor": strong_floor,
        "gauss_fibre_multiplicity": gauss_multiplicity,
        "interpretation": (
            "Values span H^0(P^1,O(3))^*, so absorption is ambient; "
            "the constant Gauss map has multiplicity four; the baseline is "
            "attained while the strong floor fails."
        ),
        "status": "PASS" if passed else "FAIL",
    }
    if args.json:
        print(json.dumps(report, indent=2, sort_keys=True))
    else:
        for key, value in report.items():
            print(f"{key}: {value}")
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
