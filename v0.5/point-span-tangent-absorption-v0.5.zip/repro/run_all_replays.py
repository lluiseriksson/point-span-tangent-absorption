#!/usr/bin/env python3
"""Run every v0.5 replay and write deterministic JSON reports."""

from __future__ import annotations

import hashlib
import json
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parent
PACKAGE_ROOT = ROOT.parent
RESULTS = ROOT / "results"
SCRIPTS = (
    ("linear_p1_sharpness", "verify_linear_p1_sharpness.py"),
    ("simplex_fixtures", "verify_simplex_fixtures.py"),
    ("quadric_grid", "verify_quadric_tangent_absorption.py"),
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def write_json(path: Path, payload: object) -> None:
    path.write_text(
        json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )


def main() -> int:
    RESULTS.mkdir(parents=True, exist_ok=True)
    summary_entries: list[dict[str, object]] = []
    overall_pass = True

    for name, filename in SCRIPTS:
        script = ROOT / filename
        completed = subprocess.run(
            [sys.executable, str(script), "--json"],
            cwd=ROOT,
            check=False,
            capture_output=True,
            text=True,
            encoding="utf-8",
        )
        if completed.returncode != 0:
            overall_pass = False
            report: object = {
                "status": "FAIL",
                "returncode": completed.returncode,
                "stdout": completed.stdout,
                "stderr": completed.stderr,
            }
        else:
            try:
                report = json.loads(completed.stdout)
            except json.JSONDecodeError as error:
                overall_pass = False
                report = {
                    "status": "FAIL",
                    "error": f"invalid JSON: {error}",
                    "stdout": completed.stdout,
                    "stderr": completed.stderr,
                }

        report_path = RESULTS / f"{name}.json"
        write_json(report_path, report)
        status = report.get("status") if isinstance(report, dict) else "FAIL"
        if status != "PASS":
            overall_pass = False
        summary_entries.append(
            {
                "name": name,
                "script": filename,
                "script_sha256": sha256(script),
                "result": f"repro/results/{report_path.name}",
                "result_sha256": sha256(report_path),
                "status": status,
            }
        )

    summary = {
        "status": "PASS" if overall_pass else "FAIL",
        "scope": (
            "Deterministic finite rank replays. Passing results certify only "
            "the listed fixtures, not the universal theorem, novelty, or priority."
        ),
        "replays": summary_entries,
    }
    write_json(RESULTS / "all_replays.json", summary)
    write_json(PACKAGE_ROOT / "results.json", summary)
    print(json.dumps(summary, indent=2, sort_keys=True))
    return 0 if overall_pass else 1


if __name__ == "__main__":
    raise SystemExit(main())

